'use strict';

module.exports = {
  overrides: [
    {
      files: ['lastExtract.js'],
      rules: {
        'comma-dangle': 'off',
      },
    },
  ],
};
