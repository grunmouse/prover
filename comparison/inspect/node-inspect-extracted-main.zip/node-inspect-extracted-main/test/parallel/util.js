'use strict';

// Simulate the full util package around inspect
module.exports = require('../../src/inspect.js');
