const foo = 4;
export default foo;
